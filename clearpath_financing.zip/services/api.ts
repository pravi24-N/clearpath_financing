
import { RiskProfile } from '../types';

// Points to the Flask Python server
const API_BASE_URL = 'http://localhost:8000';

export const apiService = {
  /**
   * Pings the Python server health check endpoint
   */
  async checkHealth(): Promise<boolean> {
    try {
      const response = await fetch(`${API_BASE_URL}/health`, {
        signal: AbortSignal.timeout(3000) // Timeout after 3s
      });
      if (!response.ok) return false;
      const data = await response.json();
      return data.status === "online" && data.database.includes("Connected");
    } catch {
      return false;
    }
  },

  /**
   * Adds a new Risk Profile record to the MySQL database via Flask
   */
  async addProfile(profile: RiskProfile): Promise<any> {
    const response = await fetch(`${API_BASE_URL}/profiles`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profile)
    });
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Failed to save to Python/SQL Backend');
    }
    return response.json();
  },

  /**
   * Fetches all Risk Profiles for a specific user from MySQL via Flask
   */
  async getProfiles(userUuid?: string): Promise<RiskProfile[]> {
    const url = userUuid ? `${API_BASE_URL}/profiles?user_uuid=${userUuid}` : `${API_BASE_URL}/profiles`;
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to fetch from Python/SQL Backend');
    return response.json();
  },

  /**
   * Removes a Risk Profile from MySQL by ID via Flask
   */
  async deleteProfile(id: number): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/profiles/${id}`, {
      method: 'DELETE'
    });
    if (!response.ok) throw new Error('Failed to delete from Python/SQL Backend');
  },

  /**
   * Fetches live rates as per architecture screenshot
   */
  async getLiveRates(): Promise<any> {
    const response = await fetch(`${API_BASE_URL}/api/rates`);
    if (!response.ok) throw new Error('Failed to fetch rates');
    return response.json();
  },

  /**
   * Saves a rate alert to MySQL as per architecture screenshot
   */
  async saveAlert(email: string, targetRate: number): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/api/alert`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, target_rate: targetRate })
    });
    if (!response.ok) throw new Error('Failed to save alert');
  }
};
