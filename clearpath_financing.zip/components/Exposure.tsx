
import React, { useState } from 'react';
import { AGENTS } from '../constants';
import { Phone, MapPin, BadgeCheck, Mail, Search, Filter, Trash2, Calendar, TrendingUp, ShieldAlert } from 'lucide-react';
import { RiskProfile } from '../types';
import { apiService } from '../services/api';

interface ExposureProps {
  isDarkMode: boolean;
  profiles: RiskProfile[];
  onRefreshProfiles: () => void;
  isBackendDown: boolean;
}

const Exposure: React.FC<ExposureProps> = ({ isDarkMode, profiles, onRefreshProfiles, isBackendDown }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');

  const categories = ['All', 'Luxury', 'First-time', 'Tech', 'Commercial'];

  const filteredAgents = AGENTS.filter(agent => {
    const matchesSearch = agent.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          agent.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = activeFilter === 'All' || agent.specialty.includes(activeFilter);
    return matchesSearch && matchesFilter;
  });

  const handleDeleteProfile = async (id: number) => {
    if (confirm('Delete this risk profile from SQL database?')) {
      try {
        await apiService.deleteProfile(id);
        onRefreshProfiles();
      } catch (e) {
        alert("Failed to delete. Backend might be unreachable.");
      }
    }
  };

  return (
    <div className="space-y-16">
      {/* Risk Profile Dashboard (Python/SQL View) */}
      <section className="space-y-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className={`text-4xl font-black font-brand ${isDarkMode ? 'text-blue-400' : 'text-blue-900'}`}>Risk Profile Dashboard</h2>
            <p className="opacity-60 text-sm italic">Direct SQL connection via Python FastAPI</p>
          </div>
          {isBackendDown && (
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-500/10 text-red-500 text-[10px] font-black uppercase tracking-widest border border-red-500/20">
              <ShieldAlert size={14} /> Backend Offline
            </div>
          )}
        </div>

        {profiles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {profiles.map(profile => (
              <div key={profile.id} className={`p-6 rounded-3xl border transition-all hover:scale-[1.02] ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-black/5 shadow-lg'}`}>
                <div className="flex justify-between items-start mb-6">
                  <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                    profile.category === 'MORTGAGE' ? 'bg-blue-500/10 text-blue-500' : 'bg-green-500/10 text-green-500'
                  }`}>
                    {profile.category}
                  </div>
                  <button onClick={() => handleDeleteProfile(profile.id!)} className="text-red-500 opacity-40 hover:opacity-100 transition-opacity">
                    <Trash2 size={16} />
                  </button>
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-end">
                    <div>
                      <p className="text-[10px] font-bold opacity-30 uppercase tracking-widest">Monthly Burden</p>
                      <p className="text-2xl font-black font-brand">₹{profile.target_price.toLocaleString()}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] font-bold opacity-30 uppercase tracking-widest">End Year</p>
                      <p className="text-sm font-bold">{new Date(profile.renewal_date).getFullYear()}</p>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t border-white/5 space-y-2">
                    <div className="flex items-center gap-2 text-xs opacity-60">
                      <TrendingUp size={12} className="text-blue-500" />
                      SQL ID: #{profile.id} • Loan: ₹{profile.data_payload.loanAmount?.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className={`p-12 rounded-[3rem] border-2 border-dashed text-center opacity-40 ${isDarkMode ? 'border-white/10' : 'border-black/10'}`}>
            <p className="font-brand italic">
              {isBackendDown ? 'Start main.py to see your SQL records.' : 'No SQL records found. Save a calculation to populate this.'}
            </p>
          </div>
        )}
      </section>

      {/* Agent Network Section */}
      <section className="space-y-12 pt-16 border-t border-white/5">
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <h2 className={`text-4xl md:text-6xl font-black font-brand ${isDarkMode ? 'text-blue-400' : 'text-blue-800'}`}>Agent Exposure</h2>
          <p className="opacity-60">Verified 2025 lending experts. Direct access to market insights.</p>
        </div>

        <div className="flex flex-col md:flex-row gap-4 items-center justify-between max-w-5xl mx-auto">
          <div className={`relative w-full md:w-96 group`}>
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 opacity-40 group-focus-within:text-blue-500 transition-all" size={18} />
            <input 
              type="text"
              placeholder="Search Mumbai, Bangalore, Chennai..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full pl-12 pr-4 py-3 rounded-2xl border outline-none transition-all ${
                isDarkMode ? 'bg-white/5 border-white/10 focus:border-blue-500' : 'bg-white border-black/10 focus:border-blue-600 shadow-sm'
              }`}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredAgents.map(agent => (
            <div 
              key={agent.id}
              className={`group relative rounded-3xl overflow-hidden transition-all hover:-translate-y-2 ${isDarkMode ? 'bg-white/5 border border-white/10 hover:border-blue-500/50' : 'bg-white border border-black/5 shadow-lg'}`}
            >
              <div className="h-48 relative overflow-hidden">
                <img src={agent.image} alt={agent.name} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                <div className="absolute bottom-4 left-4 flex items-center gap-2 text-white">
                  <BadgeCheck size={16} className="text-blue-400" />
                  <span className="text-[10px] font-bold uppercase tracking-widest">Verified 2025</span>
                </div>
              </div>

              <div className="p-6 space-y-6">
                <div>
                  <h3 className="text-xl font-bold font-brand">{agent.name}</h3>
                  <p className="text-xs font-medium text-blue-500 uppercase tracking-tighter">{agent.specialty}</p>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center gap-3 opacity-60">
                    <Phone size={14} className="text-blue-500" />
                    <span className="text-xs font-medium">{agent.contact}</span>
                  </div>
                  <div className="flex items-center gap-3 opacity-60">
                    <MapPin size={14} className="text-blue-500" />
                    <span className="text-xs font-medium">{agent.location}</span>
                  </div>
                </div>
                <button className={`w-full py-3 rounded-xl flex items-center justify-center gap-2 text-xs font-bold transition-all ${isDarkMode ? 'bg-blue-500/10 text-blue-400 hover:bg-blue-500 hover:text-white' : 'bg-blue-600 text-white hover:bg-blue-700'}`}>
                  <Mail size={14} /> Send Inquiry
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Exposure;
