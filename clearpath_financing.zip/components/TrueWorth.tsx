
import React, { useState, useMemo, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { ArrowUpRight, ArrowDownRight, Minus, IndianRupee, Info, Database, AlertCircle, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';
import { apiService } from '../services/api';

const InputField = ({ label, value, onChange, prefix, isDarkMode }: any) => (
  <div className="space-y-2">
    <label className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40 block">{label}</label>
    <div className="relative group">
      {prefix && <div className="absolute left-0 top-1/2 -translate-y-1/2 opacity-30 group-focus-within:opacity-100 transition-opacity">{prefix}</div>}
      <input 
        type="number"
        value={value === 0 ? '' : value}
        onChange={(e) => onChange(e.target.value === '' ? 0 : Number(e.target.value))}
        className={`w-full bg-transparent border-b-2 py-2 text-lg font-bold outline-none transition-all ${
          isDarkMode ? 'border-white/10 focus:border-blue-500' : 'border-black/10 focus:border-blue-600'
        } ${prefix ? 'pl-6' : ''}`}
      />
    </div>
  </div>
);

interface TrueWorthProps {
  isDarkMode: boolean;
  userUuid: string;
  onSaveProfile: () => void;
  isBackendDown: boolean;
}

const TrueWorth: React.FC<TrueWorthProps> = ({ isDarkMode, userUuid, onSaveProfile, isBackendDown }) => {
  const [propertyValue, setPropertyValue] = useState<number>(8000000);
  const [loanAmount, setLoanAmount] = useState<number>(6000000);
  const [interestRate, setInterestRate] = useState<number>(8.5);
  const [term, setTerm] = useState<number>(20);
  const [cibilScore, setCibilScore] = useState<number>(750);
  const [extraPayment, setExtraPayment] = useState<number>(5000);
  const [maintenanceRate, setMaintenanceRate] = useState<number>(2);
  const [isSaving, setIsSaving] = useState(false);

  const [snapshot, setSnapshot] = useState<{emi: number, total: number} | null>(null);

  const calculations = useMemo(() => {
    const monthlyRate = interestRate / 100 / 12;
    const n = term * 12;
    let baseEMI = 0;
    if (loanAmount > 0 && monthlyRate > 0 && n > 0) {
      baseEMI = Math.round((loanAmount * monthlyRate * Math.pow(1 + monthlyRate, n)) / (Math.pow(1 + monthlyRate, n) - 1));
    }
    const monthlyMaintenance = Math.round((propertyValue * (maintenanceRate / 100)) / 12);
    const totalOutflow = baseEMI + monthlyMaintenance + extraPayment;

    const points = [];
    for (let i = 0; i <= term; i += Math.max(1, Math.floor(term / 10))) {
      points.push({
        year: `Y${i}`,
        'Actual EMI': baseEMI,
        'Total Outflow': totalOutflow,
      });
    }

    return { baseEMI, monthlyMaintenance, totalOutflow, points };
  }, [propertyValue, loanAmount, interestRate, term, extraPayment, maintenanceRate]);

  const cibilAnalysis = useMemo(() => {
    if (cibilScore >= 800) {
      return {
        label: 'Exceptional',
        color: 'text-emerald-500',
        icon: <CheckCircle2 size={14} className="text-emerald-500" />,
        impact: 'Eligible for lowest possible repo-linked rates. High probability of zero processing fee offers.',
        eligibility: 'High'
      };
    } else if (cibilScore >= 750) {
      return {
        label: 'Excellent',
        color: 'text-blue-500',
        icon: <CheckCircle2 size={14} className="text-blue-500" />,
        impact: 'Very competitive interest rates. Fast-track processing enabled by most Indian banks.',
        eligibility: 'High'
      };
    } else if (cibilScore >= 700) {
      return {
        label: 'Good',
        color: 'text-blue-400',
        icon: <Info size={14} className="text-blue-400" />,
        impact: 'Standard market rates apply. Strong eligibility but less leverage for negotiation on fees.',
        eligibility: 'Moderate-High'
      };
    } else if (cibilScore >= 650) {
      return {
        label: 'Fair',
        color: 'text-amber-500',
        icon: <AlertTriangle size={14} className="text-amber-500" />,
        impact: 'Risk premium may be added to base rates (+0.25% to 0.50%). Stricter documentation required.',
        eligibility: 'Moderate'
      };
    } else {
      return {
        label: 'Poor',
        color: 'text-red-500',
        icon: <XCircle size={14} className="text-red-500" />,
        impact: 'High risk of rejection. Recommended to improve score or add a co-applicant with a 750+ score.',
        eligibility: 'Low'
      };
    }
  }, [cibilScore]);

  useEffect(() => {
    if (!snapshot) {
      setSnapshot({ emi: calculations.baseEMI, total: calculations.totalOutflow });
    }
  }, []);

  const takeNewSnapshot = () => {
    setSnapshot({ emi: calculations.baseEMI, total: calculations.totalOutflow });
  };

  const handleSaveToDatabase = async () => {
    if (isBackendDown) {
      alert("Cannot save: Python Backend is offline. Please start 'main.py' to enable SQL storage.");
      return;
    }
    setIsSaving(true);
    try {
      await apiService.addProfile({
        user_uuid: userUuid,
        category: 'MORTGAGE',
        data_payload: {
          propertyValue,
          loanAmount,
          interestRate,
          term,
          emi: calculations.baseEMI
        },
        renewal_date: new Date(new Date().getFullYear() + term, 0, 1).toISOString().split('T')[0],
        target_price: calculations.totalOutflow
      });
      onSaveProfile();
      alert('Risk Profile saved to SQL database via Python Backend!');
    } catch (e) {
      console.error(e);
      alert('Failed to save to database. Ensure Python server is running.');
    } finally {
      setIsSaving(false);
    }
  };

  const renderDiff = (current: number, prev: number) => {
    const diff = current - prev;
    if (diff === 0) return <span className="opacity-40 text-[10px]"><Minus size={10} className="inline mr-1" /> No change</span>;
    return diff > 0 
      ? <span className="text-red-500 text-[10px] font-bold"><ArrowUpRight size={10} className="inline mr-1" /> +₹{Math.abs(diff).toLocaleString()}</span>
      : <span className="text-green-500 text-[10px] font-bold"><ArrowDownRight size={10} className="inline mr-1" /> -₹{Math.abs(diff).toLocaleString()}</span>;
  };

  const ltv = Math.round((loanAmount / propertyValue) * 100);

  return (
    <div className="space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-end gap-6">
        <div className="space-y-2">
          <h2 className={`text-5xl md:text-7xl font-black font-brand leading-none ${isDarkMode ? 'text-blue-400' : 'text-blue-900'}`}>True_Worth</h2>
          <p className="opacity-60 text-lg italic">2025 Indian Mortgage Analyzer (₹)</p>
        </div>
        <div className="flex gap-4">
          <button 
            onClick={takeNewSnapshot}
            className={`px-6 py-3 rounded-2xl text-xs font-bold transition-all ${
              isDarkMode ? 'bg-white/5 border border-white/10 hover:bg-white/10' : 'bg-white border border-black/10 shadow-sm hover:bg-gray-50'
            }`}
          >
            Snapshot State
          </button>
          <button 
            onClick={handleSaveToDatabase}
            disabled={isSaving}
            className={`px-6 py-3 rounded-2xl text-xs font-bold transition-all flex items-center gap-2 ${
              isBackendDown ? 'bg-gray-500 opacity-50 cursor-not-allowed' : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            <Database size={14} /> {isSaving ? 'Saving...' : 'Save to SQL DB'}
          </button>
        </div>
      </div>

      {isBackendDown && (
        <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center gap-4 text-red-500 text-xs font-bold">
          <AlertCircle size={20} />
          <span>Note: Python Backend (main.py) is offline. Database functions are disabled.</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className={`lg:col-span-4 p-10 rounded-[3rem] space-y-8 h-fit ${isDarkMode ? 'bg-white/5 border border-white/10' : 'bg-gray-50 border border-gray-100 shadow-sm'}`}>
          <InputField label="Property Value" value={propertyValue} onChange={setPropertyValue} prefix={<IndianRupee size={14}/>} isDarkMode={isDarkMode} />
          <InputField label="Loan Amount" value={loanAmount} onChange={setLoanAmount} prefix={<IndianRupee size={14}/>} isDarkMode={isDarkMode} />
          <div className="grid grid-cols-2 gap-6">
            <InputField label="Interest Rate (%)" value={interestRate} onChange={setInterestRate} isDarkMode={isDarkMode} />
            <InputField label="Tenure (Years)" value={term} onChange={setTerm} isDarkMode={isDarkMode} />
          </div>
          <div className="grid grid-cols-2 gap-6">
            <InputField label="CIBIL Score" value={cibilScore} onChange={setCibilScore} isDarkMode={isDarkMode} />
            <InputField label="Prepayment / Mo" value={extraPayment} onChange={setExtraPayment} prefix={<IndianRupee size={12}/>} isDarkMode={isDarkMode} />
          </div>
          <InputField label="Maintenance Budget (%)" value={maintenanceRate} onChange={setMaintenanceRate} isDarkMode={isDarkMode} />
          
          <div className={`p-6 rounded-[2rem] border transition-all duration-500 ${isDarkMode ? 'bg-blue-500/5 border-blue-500/10' : 'bg-blue-50 border-blue-200'} space-y-4`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-blue-500 font-bold text-[10px] uppercase tracking-widest">
                <Info size={12}/> Profile Insights
              </div>
              <div className={`flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest ${cibilAnalysis.color}`}>
                {cibilAnalysis.icon} {cibilAnalysis.label}
              </div>
            </div>
            
            <div className="space-y-3">
              <p className="text-xs opacity-80 leading-relaxed italic">
                "{cibilAnalysis.impact}"
              </p>
              
              <div className="grid grid-cols-2 gap-4 pt-2 border-t border-blue-500/10">
                <div>
                  <p className="text-[10px] font-bold opacity-40 uppercase tracking-widest mb-1">Eligibility</p>
                  <p className={`text-xs font-black ${cibilAnalysis.color}`}>{cibilAnalysis.eligibility}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold opacity-40 uppercase tracking-widest mb-1">LTV Ratio</p>
                  <p className={`text-xs font-black ${ltv > 80 ? 'text-amber-500' : 'text-blue-500'}`}>{ltv}%</p>
                </div>
              </div>
              
              {ltv > 80 && (
                <p className="text-[9px] text-amber-500 font-bold uppercase leading-tight">
                  <AlertTriangle size={8} className="inline mr-1"/> High LTV detected. Expect stricter insurance requirements.
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="lg:col-span-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className={`p-8 rounded-[2rem] border transition-all ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-black/5 shadow-md'}`}>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-40 mb-2">Base Monthly EMI</p>
              <div className="flex items-baseline gap-2">
                <span className="text-5xl font-black font-brand">₹{calculations.baseEMI.toLocaleString()}</span>
              </div>
              <div className="mt-3">
                {snapshot && renderDiff(calculations.baseEMI, snapshot.emi)}
              </div>
            </div>
            <div className={`p-8 rounded-[2rem] border transition-all ${isDarkMode ? 'bg-pink-500/5 border-pink-500/20' : 'bg-pink-50 border-pink-100 shadow-md'}`}>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-pink-500 mb-2">Total Monthly Burden</p>
              <div className="flex items-baseline gap-2">
                <span className="text-5xl font-black font-brand text-pink-600">₹{calculations.totalOutflow.toLocaleString()}</span>
              </div>
              <div className="mt-3">
                {snapshot && renderDiff(calculations.totalOutflow, snapshot.total)}
              </div>
            </div>
          </div>

          <div className={`p-10 rounded-[3rem] ${isDarkMode ? 'bg-black/40 border border-white/5' : 'bg-white shadow-2xl border border-black/5'}`}>
            <h3 className="text-xl font-bold font-brand flex items-center gap-3 mb-10">
              <div className="w-4 h-4 rounded-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]" />
              Comparative Debt Visualization
            </h3>
            <div className="h-[380px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={calculations.points}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDarkMode ? '#ffffff08' : '#00000008'} />
                  <XAxis dataKey="year" stroke={isDarkMode ? '#ffffff30' : '#00000030'} axisLine={false} tickLine={false} dy={10} />
                  <YAxis hide />
                  <Tooltip 
                    contentStyle={{ backgroundColor: isDarkMode ? '#1a1a1a' : '#fff', border: 'none', borderRadius: '16px', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.1)' }}
                    formatter={(v: any) => [`₹${v.toLocaleString()}`, '']}
                  />
                  <Legend verticalAlign="top" height={40} iconType="circle" />
                  <Line name="Actual EMI" type="monotone" dataKey="Actual EMI" stroke={isDarkMode ? '#3b82f6' : '#2563eb'} strokeWidth={4} />
                  <Line name="Total Outflow" type="monotone" dataKey="Total Outflow" stroke="#db2777" strokeWidth={4} strokeDasharray="5 5" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrueWorth;
