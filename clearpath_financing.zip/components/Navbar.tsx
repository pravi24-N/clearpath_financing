
import React, { useState } from 'react';
import { Page, EMIReminder } from '../types';
import { Bell, Plus, Trash2, Sun, Moon, Calculator, TrendingUp, Users, Menu, X } from 'lucide-react';

interface NavbarProps {
  currentPage: Page;
  setCurrentPage: (p: Page) => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
  reminders: EMIReminder[];
  addReminder: (r: EMIReminder) => void;
  removeReminder: (id: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ 
  currentPage, setCurrentPage, isDarkMode, toggleTheme, 
  reminders, addReminder, removeReminder 
}) => {
  const [showReminders, setShowReminders] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [newRemLabel, setNewRemLabel] = useState('');
  const [newRemAmount, setNewRemAmount] = useState('');

  const handleAdd = () => {
    if (!newRemLabel || !newRemAmount) return;
    addReminder({
      id: Date.now().toString(),
      label: newRemLabel,
      amount: parseFloat(newRemAmount),
      dueDate: new Date().toISOString().split('T')[0]
    });
    setNewRemLabel('');
    setNewRemAmount('');
  };

  const navItems = [
    { id: 'true_worth', icon: <Calculator size={18} />, label: 'True_Worth' },
    { id: 'trends', icon: <TrendingUp size={18} />, label: 'Trends' },
    { id: 'exposure', icon: <Users size={18} />, label: 'Exposure' },
  ];

  const handlePageChange = (page: Page) => {
    setCurrentPage(page);
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all ${isDarkMode ? 'bg-black/80 border-b border-white/10' : 'bg-white/80 border-b border-black/10'} backdrop-blur-xl`}>
        <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
          
          {/* Mobile Menu Toggle */}
          <button 
            onClick={() => setIsMobileMenuOpen(true)}
            className="md:hidden p-2 -ml-2 opacity-70 hover:opacity-100 transition-opacity"
          >
            <Menu size={24} />
          </button>

          {/* LOGO: Sole way to get back to home */}
          <div className="flex items-center cursor-pointer group flex-1 md:flex-none justify-center md:justify-start" onClick={() => handlePageChange('home')}>
            <span className="font-brand text-xl font-bold tracking-tight group-hover:text-blue-500 transition-colors">ClearPath_Financing</span>
          </div>

          {/* DESKTOP NAVIGATION */}
          <div className="hidden md:flex items-center gap-8">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => handlePageChange(item.id as Page)}
                className={`flex items-center gap-2 text-sm font-medium transition-all ${
                  currentPage === item.id ? 'text-blue-500 scale-105' : 'opacity-60 hover:opacity-100'
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 md:gap-4">
            <button onClick={toggleTheme} className="p-2 rounded-full hover:bg-white/10 transition-colors">
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            
            <div className="relative">
              <button 
                onClick={() => setShowReminders(!showReminders)}
                className="p-2 rounded-full bg-blue-500 text-white hover:bg-blue-600 transition-colors flex items-center gap-1 shadow-lg shadow-blue-500/20"
              >
                <Bell size={20} />
                <Plus size={14} className="hidden sm:inline" />
              </button>

              {showReminders && (
                <div className={`absolute right-0 mt-4 w-72 md:w-80 p-4 rounded-2xl shadow-2xl border ${isDarkMode ? 'bg-[#121212] border-white/10' : 'bg-white border-black/10'} transform origin-top-right transition-all z-[60]`}>
                  <h3 className="text-sm font-bold mb-4 flex items-center gap-2">
                    <Bell size={16} className="text-blue-500" /> EMI Tracker (₹)
                  </h3>
                  
                  <div className="space-y-3 max-h-60 overflow-y-auto mb-4 pr-2">
                    {reminders.length === 0 && <p className="text-xs opacity-50 text-center py-6">No active reminders</p>}
                    {reminders.map(rem => (
                      <div key={rem.id} className="flex items-center justify-between p-3 rounded-xl bg-black/5 dark:bg-white/5 border border-transparent hover:border-blue-500/20 transition-all">
                        <div>
                          <p className="text-xs font-bold">{rem.label}</p>
                          <p className="text-[10px] opacity-60 font-medium">₹{rem.amount.toLocaleString()} • {rem.dueDate}</p>
                        </div>
                        <button onClick={() => removeReminder(rem.id)} className="p-1.5 text-red-500/60 hover:text-red-500 transition-colors">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-2 pt-4 border-t border-white/5">
                    <input 
                      type="text" 
                      placeholder="Bank/Label" 
                      className="w-full text-xs p-3 rounded-xl bg-black/5 dark:bg-white/5 border border-transparent outline-none focus:border-blue-500 transition-all"
                      value={newRemLabel}
                      onChange={(e) => setNewRemLabel(e.target.value)}
                    />
                    <input 
                      type="number" 
                      placeholder="EMI Amount (₹)" 
                      className="w-full text-xs p-3 rounded-xl bg-black/5 dark:bg-white/5 border border-transparent outline-none focus:border-blue-500 transition-all"
                      value={newRemAmount}
                      onChange={(e) => setNewRemAmount(e.target.value)}
                    />
                    <button 
                      onClick={handleAdd}
                      className="w-full py-3 bg-blue-500 text-white rounded-xl text-xs font-bold hover:bg-blue-600 transition-all active:scale-[0.98]"
                    >
                      Add Reminder
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* MOBILE SIDEBAR (DRAWER) */}
      <div 
        className={`fixed inset-0 z-[100] transition-opacity duration-300 ${isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
      >
        {/* Backdrop */}
        <div 
          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        />
        
        {/* Sidebar Panel */}
        <div 
          className={`absolute top-0 left-0 bottom-0 w-[280px] max-w-[80%] p-6 transition-transform duration-300 ease-out ${
            isDarkMode ? 'bg-[#0a0a0a] text-white' : 'bg-white text-gray-900'
          } ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full shadow-2xl'}`}
        >
          <div className="flex items-center justify-between mb-12">
            <span className="font-brand text-lg font-bold">Menu</span>
            <button 
              onClick={() => setIsMobileMenuOpen(false)}
              className="p-2 rounded-full hover:bg-white/10"
            >
              <X size={20} />
            </button>
          </div>

          <div className="flex flex-col gap-4">
            <button
              onClick={() => handlePageChange('home')}
              className={`flex items-center gap-4 p-4 rounded-2xl transition-all ${
                currentPage === 'home' 
                  ? 'bg-blue-500 text-white shadow-xl shadow-blue-500/20 font-bold' 
                  : 'hover:bg-white/5 opacity-60'
              }`}
            >
              <div className="w-5 h-5 flex items-center justify-center">H</div>
              Home
            </button>
            
            <div className="my-2 h-px bg-white/5 w-full" />

            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => handlePageChange(item.id as Page)}
                className={`flex items-center gap-4 p-4 rounded-2xl transition-all ${
                  currentPage === item.id 
                    ? 'bg-blue-500 text-white shadow-xl shadow-blue-500/20 font-bold' 
                    : 'hover:bg-white/5 opacity-60'
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </div>

          <div className="absolute bottom-8 left-6 right-6">
            <p className="text-[10px] uppercase font-bold tracking-[0.2em] opacity-30 mb-2">2025 Edition</p>
            <p className="text-[8px] opacity-20 uppercase tracking-widest leading-loose">
              Classy Interactive <br /> PWA Experience
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;
