
import React, { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { HISTORICAL_RATES } from '../constants';
import { Bell, Info, ShieldAlert } from 'lucide-react';

const Trends: React.FC<{ isDarkMode: boolean }> = ({ isDarkMode }) => {
  const [selectedPoint, setSelectedPoint] = useState(HISTORICAL_RATES[HISTORICAL_RATES.length - 1]);

  const handlePointClick = (data: any) => {
    if (data && data.activePayload && data.activePayload.length > 0) {
      setSelectedPoint(data.activePayload[0].payload);
    }
  };

  return (
    <div className="space-y-12">
      <div className="flex flex-col md:flex-row justify-between items-end gap-4">
        <div className="space-y-2">
          <h2 className={`text-4xl md:text-6xl font-black font-brand ${isDarkMode ? 'text-red-500' : 'text-red-700'}`}>Trends & Evolution</h2>
          <p className="opacity-60">Strategic analysis of mortgage rate shifts.</p>
        </div>
        <div className={`p-4 rounded-2xl flex items-center gap-4 border animate-pulse ${isDarkMode ? 'bg-red-500/10 border-red-500/30' : 'bg-red-50 border-red-200'}`}>
          <div className="p-2 rounded-full bg-red-500 text-white">
            <Bell size={20} />
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-widest">Rate Alert Active</p>
            <p className="text-[10px] opacity-60">Monitoring 24/7 Fed signals</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3 space-y-8">
          <div className={`p-8 rounded-3xl ${isDarkMode ? 'bg-white/5 border border-white/10' : 'bg-white shadow-xl border border-black/5'}`}>
            <h3 className="text-sm font-bold mb-8 flex items-center gap-2 opacity-60">
              <TrendingUpIcon size={16} /> CLICK OR HOVER FOR CONTEXT
            </h3>
            <div className="h-[450px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={HISTORICAL_RATES} onClick={handlePointClick} onMouseMove={handlePointClick}>
                  <defs>
                    <linearGradient id="colorRate" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDarkMode ? '#ffffff10' : '#00000010'} />
                  <XAxis dataKey="year" stroke={isDarkMode ? '#ffffff60' : '#00000060'} axisLine={false} tickLine={false} />
                  <YAxis domain={[0, 8]} stroke={isDarkMode ? '#ffffff60' : '#00000060'} axisLine={false} tickLine={false} />
                  <Tooltip 
                    content={() => null} 
                    cursor={{ stroke: '#ef4444', strokeWidth: 2, strokeDasharray: '5 5' }} 
                  />
                  <Area 
                    type="monotone" 
                    dataKey="rate" 
                    stroke="#ef4444" 
                    fillOpacity={1} 
                    fill="url(#colorRate)" 
                    strokeWidth={4} 
                    activeDot={{ r: 8, fill: '#ef4444', stroke: '#fff', strokeWidth: 2 }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="lg:col-span-1 flex flex-col gap-6">
          <div className={`p-6 rounded-3xl h-full flex flex-col justify-center transform transition-all hover:scale-[1.02] ${isDarkMode ? 'bg-red-500/10 border border-red-500/20' : 'bg-red-50 border border-red-200'}`}>
            <div className="space-y-2 mb-8">
              <p className="text-5xl font-black font-brand text-red-500">{selectedPoint.year}</p>
              <p className="text-xl font-bold opacity-60">Average Rate: {selectedPoint.rate}%</p>
            </div>
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-red-500">
                <ShieldAlert size={18} />
                <span className="text-xs font-bold uppercase tracking-widest">Historical Impact</span>
              </div>
              <p className="text-sm leading-relaxed opacity-80 italic">
                "{selectedPoint.impact}"
              </p>
            </div>
            <div className="mt-8 pt-8 border-t border-red-500/20 text-[10px] opacity-40 uppercase tracking-widest leading-loose">
              Historical rates are benchmarks. Actual rates depend on individual credit profiles and LTV ratios.
            </div>
          </div>

          <div className={`p-6 rounded-3xl border ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-black/5 shadow-lg'}`}>
            <h4 className="text-xs font-bold uppercase tracking-widest mb-4 flex items-center gap-2">
              <Info size={14} className="text-red-500" /> Current Outlook
            </h4>
            <p className="text-xs opacity-60 leading-relaxed">
              Inflation data suggests potential rate cuts in late 2024. Expert consensus remains cautious but optimistic for refinancers.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const TrendingUpIcon = ({ size }: { size: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
);

export default Trends;
