
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { HISTORICAL_RATES } from '../constants';
import { ChevronDown, MessageSquare, ShieldCheck, Sparkles, FileText, Lock } from 'lucide-react';

const Home: React.FC<{ isDarkMode: boolean }> = ({ isDarkMode }) => {
  const scrollToExplore = () => {
    document.getElementById('upcoming-features')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="space-y-24">
      {/* Hero Section */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center min-h-[70vh]">
        <div className="space-y-6">
          <div className="space-y-1">
            <p className={`text-sm font-bold tracking-widest uppercase ${isDarkMode ? 'text-green-400' : 'text-green-600'}`}>Current 2025 Home Loan Rate</p>
            <h1 className="text-8xl md:text-9xl font-black font-brand tracking-tighter">
              8.25<span className="text-4xl align-top">%</span>
            </h1>
          </div>
          <p className="max-w-md text-lg opacity-80 leading-relaxed">
            The Indian property market in 2025 is prime for strategic growth. Navigate Repo Rates and hidden ownership costs with our precision tools.
          </p>
          <button 
            onClick={scrollToExplore}
            className={`px-8 py-4 rounded-full font-bold flex items-center gap-2 group transition-all ${isDarkMode ? 'bg-green-500 text-black hover:bg-green-400' : 'bg-green-600 text-white hover:bg-green-700'}`}
          >
            Explore 2025 Outlook <ChevronDown className="group-hover:translate-y-1 transition-transform" />
          </button>
        </div>

        <div className={`h-[400px] rounded-3xl p-6 ${isDarkMode ? 'bg-white/5 border border-white/10' : 'bg-white shadow-xl border border-black/5'}`}>
          <h3 className="text-sm font-bold mb-6 flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            Interest Rate Evolution (2020 - 2025)
          </h3>
          <ResponsiveContainer width="100%" height="80%">
            <BarChart data={HISTORICAL_RATES}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={isDarkMode ? '#ffffff10' : '#00000010'} />
              <XAxis dataKey="year" stroke={isDarkMode ? '#ffffff60' : '#00000060'} axisLine={false} tickLine={false} />
              <YAxis hide />
              <Tooltip 
                cursor={{ fill: 'transparent' }} 
                contentStyle={{ 
                  backgroundColor: isDarkMode ? '#1a1a1a' : '#fff', 
                  borderColor: '#22c55e', 
                  borderRadius: '12px' 
                }} 
                formatter={(v) => [`${v}%`, 'Average Rate']}
              />
              <Bar dataKey="rate" radius={[8, 8, 0, 0]}>
                {HISTORICAL_RATES.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={index === HISTORICAL_RATES.length - 1 ? '#22c55e' : (isDarkMode ? '#4ade8040' : '#22c55e40')} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <p className="text-[10px] text-center mt-4 opacity-50 uppercase tracking-widest text-green-500 font-bold">Updated: Jan 2025 Benchmarks</p>
        </div>
      </section>

      {/* Upcoming Features Section */}
      <section id="upcoming-features" className="py-20 border-t border-white/10 space-y-16">
        <div className="text-center space-y-4">
          <h2 className={`text-5xl md:text-7xl font-black font-brand ${isDarkMode ? 'text-blue-400' : 'text-blue-900'}`}>Next-Gen Analysis</h2>
          <p className="opacity-60 max-w-xl mx-auto italic">"Let's Explore the future of real-estate intelligence together."</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* GrihaDost AI Card */}
          <div className={`p-10 rounded-[3rem] border relative overflow-hidden group cursor-not-allowed transition-all hover:scale-[1.01] ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-black/5 shadow-xl'}`}>
            <div className="absolute top-6 right-6 flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 text-blue-500 text-[10px] font-black uppercase tracking-widest border border-blue-500/20">
              <Lock size={10} /> Development Phase
            </div>
            
            <div className="flex flex-col h-full justify-between">
              <div className="space-y-6">
                <div className="w-16 h-16 rounded-2xl bg-orange-500/10 text-orange-500 flex items-center justify-center">
                  <MessageSquare size={32} />
                </div>
                <div className="space-y-2">
                  <h3 className="text-4xl font-black font-brand flex items-center gap-2">
                    GrihaDost AI <Sparkles size={24} className="text-yellow-500" />
                  </h3>
                  <p className="text-base opacity-70 leading-relaxed max-w-md">
                    Your personal 2025 real estate companion. GrihaDost will assist with state-specific stamp duty calculations and localized RERA insights.
                  </p>
                </div>
              </div>
              <div className="mt-8 pt-8 border-t border-white/5 flex gap-4">
                <div className="text-center">
                  <p className="text-[10px] uppercase font-bold opacity-30">Status</p>
                  <p className="text-xs font-bold text-orange-500">Beta Integration</p>
                </div>
                <div className="text-center">
                  <p className="text-[10px] uppercase font-bold opacity-30">ETA</p>
                  <p className="text-xs font-bold">June 2025</p>
                </div>
              </div>
            </div>
          </div>

          {/* Rent vs Buy Analyzer Card */}
          <div className={`p-10 rounded-[3rem] border relative overflow-hidden group cursor-not-allowed transition-all hover:scale-[1.01] ${isDarkMode ? 'bg-white/5 border-white/10' : 'bg-white border-black/5 shadow-xl'}`}>
            <div className="absolute top-6 right-6 flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 text-blue-500 text-[10px] font-black uppercase tracking-widest border border-blue-500/20">
              <Lock size={10} /> Development Phase
            </div>

            <div className="flex flex-col h-full justify-between">
              <div className="space-y-6">
                <div className="w-16 h-16 rounded-2xl bg-blue-500/10 text-blue-500 flex items-center justify-center">
                  <FileText size={32} />
                </div>
                <div className="space-y-2">
                  <h3 className="text-4xl font-black font-brand">Rent vs Buy</h3>
                  <p className="text-xs font-bold text-blue-500 uppercase tracking-widest">PDF Export Enabled Analysis</p>
                  <p className="text-base opacity-70 leading-relaxed max-w-md">
                    Sophisticated wealth building models. Generate high-fidelity PDF reports comparing 20-year equity trajectories across Indian metros.
                  </p>
                </div>
              </div>
              <div className="mt-8 pt-8 border-t border-white/5 flex gap-4">
                <div className="text-center">
                  <p className="text-[10px] uppercase font-bold opacity-30">Architecture</p>
                  <p className="text-xs font-bold">PDF Engine 2.0</p>
                </div>
                <div className="text-center">
                  <p className="text-[10px] uppercase font-bold opacity-30">Security</p>
                  <p className="text-xs font-bold text-blue-500">On-Device Only</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
